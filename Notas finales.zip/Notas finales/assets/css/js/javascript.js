var nombre = prompt("Ingresa un nombre: ")
var apellido = prompt("Ingresa un apellido: ")
var email = prompt("Ingresa un correo: ")
//Aquí creamos nuestro div contenedor
document.write("<div class='container'>");
document.write("<h1>Creando Tabla HTML con JavaScript y Bootstrap</h1>")
//Aquí creamos nuestra tabla con bootstrap
document.write("<table class='table'>");
//Aquí indicamos que nuestra tabla tendrá encabezado
document.write("<thead class='bg-dark text-white'>");
//Con tr definimos las columnas de la tabla
document.write("<tr>");
//Aquí definimos el tipo de dato que tendrá cada columna y su encabezado
document.write("<th scope='col'>Ramo</th>");
document.write("<th scope='col'>Nota 1</th>");
document.write("<th scope='col'>Nota 2</th>");
document.write("<th scope='col'>Nota 3</th>");
document.write("<th scope='col'>Nota 4</th>");
document.write("</tr");
//Aquí cerramos el tr donde definimos las columnas de la tabla
document.write("</thead>");
//Aquí cerramos el encabezado de nuestra tabla
//Aquí definimos el cuerpo con el contenido de la tabla según la columna
document.write("<tbody>");
document.write("<tr>");
document.write("<td scope='row'>HTML</th>");
document.write("<th scope='row'>CSS</th>");
document.write("<td>"+nombre+"</td>");
document.write("<td>"+apellido+"</td>");
document.write("<tr>");
document.write("</tbody>");
//Aquí cerramos el cuerpo con el contenido de la tabla según la columna
document.write("</table");
//Aquí cerramos nuestra tabla